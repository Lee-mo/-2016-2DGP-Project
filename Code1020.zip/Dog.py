from pico2d import *

#GAME OBJECT CLASS------------------------------------------------------------------------------------------------------

#-----------------------------------------------------------------------------------------------------------------------
class Back:#Background

    def __init__(self):
        self.x=512
        self.y=768/2
        self.frame=0
        self.left=0
        self.speed=10
        self.screenW=1024
        self.screenH=768
        self.image = load_image('RedSky.jpg')
        self.step=0

    def Draw(self):
        #self.image.clip_draw(self.frame,0,1024,768,self.x,self.y)
        x = int(self.left)
        w = min(self.image.w - x, self.screenW)
        self.image.clip_draw_to_origin(x,0,w,self.screenH,0,0)
        self.image.clip_draw_to_origin(0,0,self.screenW-w,self.screenH,w,0)

    def Update(self, frame_time, dogDir, dogState):
        self.speed=0

        if dogState!='S':
            if dogDir=='R':
                self.speed=10
            elif dogDir=='L' and self.step>0:
                self.speed=-10
        if dogState=='J':
            self.speed = self.speed*2
        self.left = (self.left + frame_time * self.speed) % self.image.w

        if dogState!='S':
            self.step = self.step + self.speed/10
            print("걸음수:", self.step)

#-----------------------------------------------------------------------------------------------------------------------
class Dog:#Merry Puppy

    def __init__(self):
        self.state = 'S'
        self.dir = 'R'
        self.x = 400
        self.y = 158
        self.frame=0
        self.jumpState=0
        self.RSimage = load_image('DogRstop.png')
        self.RWimage = load_image('DogRwalk.png')
        self.LSimage = load_image('DogLstop.png')
        self.LWimage = load_image('DogLwalk.png')
        self.RJimage = load_image('DogRjump.png')
        self.LJimage = load_image('DogLjump.png')

    def Update(self):
        if self.state=='W':
            if self.dir=='R':
                self.frame = (self.frame + 1) % 6
            elif self.dir=='L':
                self.frame = (self.frame - 1) % 6
        elif self.state=='J':
            if self.dir == 'R':
                if dog.jumpState == 0:
                    dog.y = dog.y + 20
                    if dog.y >= 250:
                        dog.jumpState = 1
                elif dog.jumpState == 1:
                    dog.y = dog.y - 20
                    if dog.y <= 250:
                        dog.jumpState = 2
                elif dog.jumpState == 2:
                    dog.y = dog.y - 20
                    if dog.y <= 158:
                        dog.y = 158
                        dog.jumpState = 0
                        dog.state = 'S'
            elif self.dir == 'L':
                if dog.jumpState == 2:
                    dog.y = dog.y + 20
                    if dog.y >= 250:
                        dog.jumpState = 1
                elif dog.jumpState == 1:
                    dog.y = dog.y - 20
                    if dog.y <= 250:
                        dog.jumpState = 0
                elif dog.jumpState == 0:
                    dog.y = dog.y - 20
                    if dog.y <= 158:
                        dog.y = 158
                        dog.jumpState = 2
                        dog.state = 'S'

    def Draw(self):
        if self.state == 'W':
            if self.dir == 'R':
                self.RWimage.clip_draw(self.frame*88,0,88,54,400,158)
            elif self.dir=='L':
                self.LWimage.clip_draw(self.frame * 88, 0, 88, 54, 400, 158)
        elif self.state == 'J':
            if self.dir=='R':
                self.RJimage.clip_draw(dog.jumpState*74,0,74,62,400,self.y)
            if self.dir=='L':
                self.LJimage.clip_draw(dog.jumpState*74,0,74,62,400,self.y)
        elif self.state== 'S':
            if self.dir=='R':
                self.RSimage.clip_draw(0,0,60,52,400,158)
            elif self.dir=='L':
                self.LSimage.clip_draw(0, 0, 60, 52, 400, 158)
#-----------------------------------------------------------------------------------------------------------------------
class Monster:

    class RedHorn:

        def __init__(self):
            self.x = 1000
            self.y = 160
            self.frame = 0
            self.scale = 10
            self.state=1 #Idle:1 move to left, 2 move to right
            self.moveCnt=0
            self.speed=4
            self.idleImage0 = load_image('RedHorn1.png')
            self.idleImage1 = load_image('RedHorn2.png')
            self.idleImage2 = load_image('RedHorn3.png')
            self.idleImage3 = load_image('RedHorn4.png')
            self.hitImage = load_image('RedHornHit.png')

        def Draw(self):
            if self.state==1:
                if self.frame == 0 :
                    self.idleImage0.draw(self.x,self.y,self.idleImage0.w/self.scale,self.idleImage0.h/self.scale)
                elif self.frame == 1:
                    self.idleImage1.draw(self.x, self.y,self.idleImage1.w/self.scale,self.idleImage1.h/self.scale)
            elif self.state==2:
                if self.frame == 0:
                    self.idleImage2.draw(self.x, self.y, self.idleImage0.w / self.scale, self.idleImage0.h / self.scale)
                elif self.frame == 1:
                    self.idleImage3.draw(self.x, self.y, self.idleImage1.w / self.scale, self.idleImage1.h / self.scale)

        def Update(self, dogState, dogDir, BackStep):
            self.frame = (self.frame+1)%2
            if BackStep > 0: #Monster location
                if dogState == 'W':
                    if dogDir == 'R':
                        self.x -= 10
                    elif dogDir == 'L':
                        self.x += 10
                elif dogState == 'J':
                    if dogDir == 'R':
                        self.x -= 20
                    elif dogDir == 'L':
                        self.x += 20
        def Move(self):
            if self.state==1:#Move to left
                self.x-=self.speed
                self.moveCnt+=1
                if self.moveCnt==20:
                    self.moveCnt=0
                    self.state=2
            elif self.state==2:#Move to right
                self.x+=self.speed
                self.moveCnt+=1
                if self.moveCnt==20:
                    self.moveCnt=0
                    self.state=1
#-----------------------------------------------------------------------------------------------------------------------

#Handle event-----------------------------------------------------------------------------------------------------------
def handle_events():
    global GAME
    global dog
    global back

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            GAME = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_RIGHT:#Right Walk
            dog.dir='R'
            dog.state='W'
        elif event.type == SDL_KEYUP and event.key == SDLK_RIGHT:#Right Stop
            dog.state='S'
        elif event.type == SDL_KEYDOWN and event.key == SDLK_LEFT:#Left Walk
            dog.dir='L'
            dog.state = 'W'
        elif event.type == SDL_KEYUP and event.key == SDLK_LEFT:#Left Stop
            dog.state = 'S'
        elif event.type == SDL_KEYDOWN and event.key == SDLK_UP:#Jump
            dog.state = 'J'
            if dog.dir=='R': dog.jumpState=0
            elif dog.dir=='L': dog.jumpState=2
#-----------------------------------------------------------------------------------------------------------------------

#INITIALIZATION CODE----------------------------------------------------------------------------------------------------
open_canvas(1024, 768)

GAME = True
dog = Dog()
back = Back()
redHorn1 = Monster.RedHorn()
#-----------------------------------------------------------------------------------------------------------------------

#GAME MAIN LOOP CODE----------------------------------------------------------------------------------------------------
while GAME:
    #Game logic
    if dog.state!='J':
        handle_events()
    dog.Update()
    back.Update(1, dog.dir, dog.state)
    redHorn1.Update(dog.state,dog.dir, back.step)
    redHorn1.Move()

    #Rendering
    clear_canvas()
    back.Draw()
    dog.Draw()
    redHorn1.Draw()
    update_canvas()

    delay(0.07)
#-----------------------------------------------------------------------------------------------------------------------

#FINALIZATION CODE------------------------------------------------------------------------------------------------------
close_canvas()