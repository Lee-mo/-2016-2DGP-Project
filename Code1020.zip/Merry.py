from pico2d import *
import game_framework
import title_state
import main_state

open_canvas(1024,768)
game_framework.run(title_state)
close_canvas()